package org.mg.matgrds;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MatgrdsApplicationTests {

	@Test
	void contextLoads() {
	}

}
