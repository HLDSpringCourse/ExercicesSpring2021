package org.mg.matgrds;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MatgrdsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MatgrdsApplication.class, args);
	}

}
